'use strict';

//main.js
var init = function init() {
  var canvas = document.getElementById('canvas');

  ReactDOM.render(React.createElement(SplashScreen, { message: 'Connecting', onLoadDone: function onLoadDone() {
      // On home page, if the balance is 0, display claim code page instead of home page.
      // Find somewhere better for this logic
      if (window.location.search == '' || window.location.search == '?' || window.location.search == 'home') {
        lbry.getBalance(function (balance) {
          if (balance <= 0) {
            window.location.href = '?claim';
          } else {
            ReactDOM.render(React.createElement(App, null), canvas);
          }
        });
      } else {
        ReactDOM.render(React.createElement(App, null), canvas);
      }
    } }), canvas);
};

init();