"use strict";

var NewAddressSection = React.createClass({
  displayName: "NewAddressSection",

  generateAddress: function generateAddress() {
    var _this = this;

    lbry.getNewAddress(function (results) {
      _this.setState({
        address: results
      });
    });
  },
  getInitialState: function getInitialState() {
    return {
      address: ""
    };
  },
  render: function render() {
    return React.createElement(
      "div",
      null,
      React.createElement(
        "h1",
        null,
        "Create New Address:"
      ),
      React.createElement(
        "button",
        { type: "button", onClick: this.generateAddress },
        "Generate New Address"
      ),
      " ",
      React.createElement("input", { type: "text", size: "60", value: this.state.address })
    );
  }
});

var SendToAddressSection = React.createClass({
  displayName: "SendToAddressSection",

  sendToAddress: function sendToAddress() {
    var _this2 = this;

    this.setState({
      results: ""
    });

    lbry.sendToAddress(this.state.amount, this.state.address, function (results) {
      if (results === true) {
        _this2.setState({
          results: "Your transaction was completed successfully."
        });
      } else {
        _this2.setState({
          results: "Something went wrong: " + results
        });
      }
    });
  },
  getInitialState: function getInitialState() {
    return {
      address: "",
      amount: 0.0,
      balance: "Checking balance...",
      results: ""
    };
  },
  componentWillMount: function componentWillMount() {
    var _this3 = this;

    lbry.getBalance(function (results) {
      _this3.setState({
        balance: results
      });
    });
  },
  setAmount: function setAmount(event) {
    this.setState({
      amount: event.target.value
    });
  },
  setAddress: function setAddress(event) {
    this.setState({
      address: event.target.value
    });
  },
  render: function render() {
    return React.createElement(
      "div",
      null,
      React.createElement(
        "h1",
        null,
        "Send To Address:"
      ),
      React.createElement(
        "label",
        { "for": "balance" },
        "Balance: ",
        this.state.balance
      ),
      React.createElement("br", null),
      React.createElement(
        "label",
        { "for": "amount" },
        "Amount:"
      ),
      " ",
      React.createElement("input", { id: "amount", type: "number", size: "10", onChange: this.setAmount }),
      React.createElement("br", null),
      React.createElement(
        "label",
        { "for": "address" },
        "Address:"
      ),
      " ",
      React.createElement("input", { id: "address", type: "text", size: "60", onChange: this.setAddress }),
      React.createElement("br", null),
      React.createElement(
        "button",
        { type: "button", onClick: this.sendToAddress },
        "Send Amount to Address"
      ),
      React.createElement("br", null),
      React.createElement("br", null),
      React.createElement(
        "h4",
        null,
        "Results:"
      ),
      React.createElement(
        "span",
        null,
        this.state.results
      )
    );
  }
});

var WalletPage = React.createClass({
  displayName: "WalletPage",

  render: function render() {
    return React.createElement(
      "main",
      { className: "page" },
      React.createElement(SubPageLogo, null),
      React.createElement(NewAddressSection, null),
      React.createElement("br", null),
      React.createElement(SendToAddressSection, null),
      React.createElement("br", null),
      React.createElement(
        "section",
        null,
        React.createElement(Link, { href: "/", label: "<< Return" })
      )
    );
  }
});