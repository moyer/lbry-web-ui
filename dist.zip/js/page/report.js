"use strict";

var ReportPage = React.createClass({
  displayName: "ReportPage",

  submitMessage: function submitMessage() {
    var _this = this;

    if (this._messageArea.value) {
      this.setState({
        submitting: true
      });
      lbry.reportBug(this._messageArea.value, function () {
        _this.setState({
          submitting: false
        });
        alert("Your bug report has been submitted! Thank you for your feedback.");
      });
      this._messageArea.value = '';
    }
  },
  getInitialState: function getInitialState() {
    return {
      submitting: false
    };
  },
  render: function render() {
    var _this2 = this;

    return React.createElement(
      "main",
      { className: "page" },
      React.createElement(SubPageLogo, null),
      React.createElement(
        "h1",
        null,
        "Report a bug"
      ),
      React.createElement(
        "section",
        null,
        React.createElement(
          "p",
          null,
          "Please describe the problem you experienced and any information you think might be useful to us. Links to screenshots are great!"
        ),
        React.createElement("textarea", { ref: function ref(t) {
            return _this2._messageArea = t;
          }, cols: "50", rows: "10", name: "message", type: "text" }),
        React.createElement(
          "div",
          null,
          React.createElement(
            "button",
            { onClick: this.submitMessage, className: this.state.submitting ? 'disabled' : '' },
            this.state.submitting ? 'Submitting...' : 'Submit bug report'
          )
        )
      ),
      React.createElement(
        "section",
        null,
        "Developers, feel free to instead ",
        React.createElement(Link, { href: "https://github.com/lbryio/lbry/issues", label: "submit an issue on GitHub" }),
        "."
      ),
      React.createElement(
        "section",
        null,
        React.createElement(Link, { href: "/?help", label: "<< Return to Help" })
      )
    );
  }
});