"use strict";

var StartPage = React.createClass({
  displayName: "StartPage",

  componentWillMount: function componentWillMount() {
    lbry.stop();
  },
  render: function render() {
    return React.createElement(
      "main",
      { className: "page" },
      React.createElement(SubPageLogo, null),
      React.createElement(
        "h1",
        null,
        "LBRY has closed"
      ),
      React.createElement(Link, { href: "lbry://lbry", label: "Click here to start LBRY" })
    );
  }
});